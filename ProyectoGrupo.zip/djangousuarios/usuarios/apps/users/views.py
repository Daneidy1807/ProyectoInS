#salir
from django.shortcuts import render, redirect
from django.contrib.auth import logout as do_logout
#login
from django.contrib.auth import authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login as do_login
#registro
from django.contrib.auth.forms import UserCreationForm
#enviar correo
from .forms import RegistrarForm
from django.template.loader import get_template
from django.core.mail import EmailMultiAlternatives
from django.conf import settings





def welcome(request):
    # Si estamos identificados devolvemos la portada
    if request.user.is_authenticated:
        return render(request, "welcome.html")
    # En otro caso redireccionamos al login
    return redirect('/login')

def register(request):
    # Creamos el formulario de autenticación vacío
    form = RegistrarForm()
    if request.method == "POST":
        # Añadimos los datos recibidos al formulario
        form = RegistrarForm(data=request.POST)
        # Si el formulario es válido...
        if form.is_valid():

            # Creamos la nueva cuenta de usuario
            user = form.save()
            correo = request.POST.get('email')
            enviarCorreo(correo)
            print(correo)

            # Si el usuario se crea correctamente 
            if user is not None:
                # Hacemos el login manualmente
                do_login(request, user)
                # Y le redireccionamos a la portada
                return redirect('/')

    # Si llegamos al final renderizamos el formulario
    return render(request, "register.html", {'form': form})

def enviarCorreo(mail):
        print(mail)
        # context = {'mail':mail}
        template = get_template('correo.html')
        content = template.render()
        email = EmailMultiAlternatives(
            'REGISTRO EXITOSO',
            '',
            settings.EMAIL_HOST_USER,
            [mail]
        )
        email.attach_alternative(content,'text/html')
        email.send()

def login(request):
     # Creamos el formulario de autenticación vacío
    form = AuthenticationForm()
    if request.method == "POST":
        # Añadimos los datos recibidos al formulario
        form = AuthenticationForm(data=request.POST)
        # Si el formulario es válido...
        if form.is_valid():
            # Recuperamos las credenciales validadas
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']

            # Verificamos las credenciales del usuario
            user = authenticate(username=username, password=password)

            # Si existe un usuario con ese nombre y contraseña
            if user is not None:
                # Hacemos el login manualmente
                do_login(request, user)
                # Y le redireccionamos a la portada
                return redirect('/')

    # Si llegamos al final renderizamos el formulario
    return render(request, "login.html", {'form': form})


def logout(request):
    #finalizamos la sesion
    do_logout(request)
    # Redireccionamos a la portada
    return redirect('/')